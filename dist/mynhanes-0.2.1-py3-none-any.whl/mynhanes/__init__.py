# # __init__.py
# __version__ = '0.1.0'
# from . import manage
# from .core import settings
# from .core.settings import *
# from .core.urls import *
